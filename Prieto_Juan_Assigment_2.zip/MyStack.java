import java.util.ArrayList;

/**
 * The `MyStack` class is a generic implementation of the `StackInterface` interface,
 * providing a basic stack data structure.
 *
 * @param <T> The type of elements that the stack can hold.
 */
public class MyStack<T> implements StackInterface<T> {
    // Private member variables

    /**
     * ArrayList to store elements in the stack.
     */
    private ArrayList<T> stack;

    /**
     * Current size of the stack.
     */
    private int size;

    /**
     * Maximum size of the stack.
     */
    private int maxSize;

    /**
     * Default constructor with a default maximum size (100).
     */
    public MyStack() {
        maxSize = 100; // Default size
        stack = new ArrayList<>(maxSize); // Initialize the ArrayList with the default size
        size = 0; // Initialize the current size to 0
    }

    /**
     * Constructor with a specified maximum size.
     *
     * @param maxSize The maximum size of the stack.
     */
    public MyStack(int maxSize) {
        this.maxSize = maxSize; // Set the maximum size
        stack = new ArrayList<>(maxSize); // Initialize the ArrayList with the specified size
        size = 0; // Initialize the current size to 0
    }

    /**
     * Check if the stack is empty.
     *
     * @return true if the stack is empty, false otherwise.
     */
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Check if the stack is full.
     *
     * @return true if the stack is full, false otherwise.
     */
    @Override
    public boolean isFull() {
        return size == maxSize;
    }

    /**
     * Remove and return the top element of the stack.
     *
     * @return The top element of the stack.
     * @throws StackUnderflowException if the stack is empty.
     */
    @Override
    public T pop() throws StackUnderflowException {
        if (isEmpty()) {
            throw new StackUnderflowException("Stack is empty");
        }
        T element = stack.remove(size - 1);
        size--;
        return element;
    }

    /**
     * Get the top element of the stack without removing it.
     *
     * @return The top element of the stack.
     * @throws StackUnderflowException if the stack is empty.
     */
    @Override
    public T top() throws StackUnderflowException {
        if (isEmpty()) {
            throw new StackUnderflowException("Stack is empty");
        }
        return stack.get(size - 1);
    }

    /**
     * Get the current size of the stack.
     *
     * @return The current size of the stack.
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * Push an element onto the top of the stack.
     *
     * @param e The element to push onto the stack.
     * @return true if the element was successfully pushed, false if the stack is full.
     * @throws StackOverflowException if the stack is full.
     */
    @Override
    public boolean push(T e) throws StackOverflowException {
        if (isFull()) {
            throw new StackOverflowException("Stack is full");
        }
        stack.add(e);
        size++;
        return true;
    }

    /**
     * Return a string representation of the stack.
     *
     * @return A string representation of the stack.
     */
    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < size; i++) {
            result.append(stack.get(i));
            if (i < size - 1) {
                result.append(" ");
            }
        }
        return result.toString();
    }

    /**
     * Return a string representation of the stack with a specified delimiter.
     *
     * @param delimiter The delimiter to use between elements.
     * @return A string representation of the stack with elements separated by the delimiter.
     */
    @Override
    public String toString(String delimiter) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < size; i++) {
            result.append(stack.get(i));
            if (i < size - 1) {
                result.append(delimiter);
            }
        }
        return result.toString();
    }

    /**
     * Fill the stack with elements from an ArrayList.
     *
     * @param list The ArrayList containing elements to fill the stack with.
     * @throws StackOverflowException if the stack becomes full during the filling process.
     */
    @Override
    public void fill(ArrayList<T> list) throws StackOverflowException {
        for (T element : list) {
            push(element);
        }
    }
}
