import java.util.ArrayList;

/**
 * The `MyQueue` class is a generic implementation of the `QueueInterface`
 * interface, providing a basic queue data structure.
 *
 * @param <T> The type of elements that the queue can hold.
 */
public class MyQueue<T> implements QueueInterface<T> {
    // Private member variables

    /**
     * Store the elements of the queue.
     */
    private ArrayList<T> queue;

    /**
     * Maximum size of the queue.
     */
    private int maxSize;

    /**
     * Constructor with a specified size.
     *
     * @param size The maximum size of the queue.
     */
    public MyQueue(int size) {
        this.queue = new ArrayList<>(size);
        this.maxSize = size;
    }

    /**
     * Default constructor with a default size (10).
     */
    public MyQueue() {
        this(10); // Default size is 10, you can change it as needed
    }

    /**
     * Check if the queue is empty.
     *
     * @return true if the queue is empty, false otherwise.
     */
    @Override
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    /**
     * Check if the queue is full.
     *
     * @return true if the queue is full, false otherwise.
     */
    @Override
    public boolean isFull() {
        return queue.size() == maxSize;
    }

    /**
     * Remove and return the front element of the queue.
     *
     * @return The front element of the queue.
     * @throws QueueUnderflowException if the queue is empty.
     */
    @Override
    public T dequeue() throws QueueUnderflowException {
        if (isEmpty()) {
            throw new QueueUnderflowException("Queue is empty");
        }
        return queue.remove(0);
    }

    /**
     * Get the current size of the queue.
     *
     * @return The current size of the queue.
     */
    @Override
    public int size() {
        return queue.size();
    }

    /**
     * Add an element to the rear of the queue.
     *
     * @param e The element to enqueue.
     * @return true if the element was successfully enqueued, false if the queue is full.
     * @throws QueueOverflowException if the queue is full.
     */
    @Override
    public boolean enqueue(T e) throws QueueOverflowException {
        if (isFull()) {
            throw new QueueOverflowException("Queue is full");
        }
        return queue.add(e);
    }

    /**
     * Return a string representation of the queue.
     *
     * @return A string representation of the queue.
     */
    @Override
    public String toString() {
        return queue.toString();
    }

    /**
     * Return a string representation of the queue with a specified delimiter.
     *
     * @param delimiter The delimiter to use between elements.
     * @return A string representation of the queue with elements separated by the delimiter.
     */
    @Override
    public String toString(String delimiter) {
        StringBuilder result = new StringBuilder();
        for (T item : queue) {
            result.append(item).append(delimiter);
        }
        return result.toString();
    }

    /**
     * Fill the queue with elements from an ArrayList.
     *
     * @param list The ArrayList containing elements to fill the queue with.
     */
    @Override
    public void fill(ArrayList<T> list) {
        for (T item : list) {
            try {
                enqueue(item);
            } catch (QueueOverflowException e) {
                // Handle the exception as needed
                e.printStackTrace();
            }
        }
    }
}


