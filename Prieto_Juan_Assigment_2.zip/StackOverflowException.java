/**
 * The `StackOverflowException` is a custom exception class that is used
 * to indicate errors related to attempting to push an element onto a full stack.
 */
public class StackOverflowException extends Exception {
    /**
     * Constructor for `StackOverflowException`.
     *
     * @param message A descriptive error message explaining the reason for the exception.
     */
    public StackOverflowException(String message) {
        super(message);
    }
}
