import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 * The `NotationStudentTest` class contains JUnit test cases for the `Notation` class,
 * specifically testing the conversion and evaluation methods.
 */
public class NotationStudentTest {

    /**
     * Test the `convertInfixToPostfix` method of the `Notation` class.
     *
     * @throws InvalidNotationFormatException if an invalid notation format is encountered.
     */
    @Test
    public void testConvertInfixToPostfix() throws InvalidNotationFormatException {
        // Test a simple expression
        String infixExpr1 = "3 + 4";
        String expectedPostfixExpr1 = "3 4 +";
        String postfixExpr1 = Notation.convertInfixToPostfix(infixExpr1);
        assertEquals(expectedPostfixExpr1, postfixExpr1);

        // Test an expression with operator precedence
        String infixExpr2 = "3 + 4 * 2";
        String expectedPostfixExpr2 = "3 4 2 * +";
        String postfixExpr2 = Notation.convertInfixToPostfix(infixExpr2);
        assertEquals(expectedPostfixExpr2, postfixExpr2);

        // Test an expression with parentheses
        String infixExpr3 = "(3 + 4) * 2";
        String expectedPostfixExpr3 = "3 4 + 2 *";
        String postfixExpr3 = Notation.convertInfixToPostfix(infixExpr3);
        assertEquals(expectedPostfixExpr3, postfixExpr3);
    }

    /**
     * Test the `convertPostfixToInfix` method of the `Notation` class.
     *
     * @throws InvalidNotationFormatException if an invalid notation format is encountered.
     */
    @Test
    public void testConvertPostfixToInfix() throws InvalidNotationFormatException {
        // Test a simple postfix expression
        String postfixExpr1 = "3 4 +";
        String expectedInfixExpr1 = "3 + 4";
        String infixExpr1 = Notation.convertPostfixToInfix(postfixExpr1);
        assertEquals(expectedInfixExpr1, infixExpr1);

        // Test a postfix expression with operator precedence
        String postfixExpr2 = "3 4 2 * +";
        String expectedInfixExpr2 = "3 + (4 * 2)";
        String infixExpr2 = Notation.convertPostfixToInfix(postfixExpr2);
        assertEquals(expectedInfixExpr2, infixExpr2);

        // Test a postfix expression with parentheses
        String postfixExpr3 = "3 4 + 2 *";
        String expectedInfixExpr3 = "(3 + 4) * 2";
        String infixExpr3 = Notation.convertPostfixToInfix(postfixExpr3);
        assertEquals(expectedInfixExpr3, infixExpr3);
    }

    /**
     * Test the `evaluatePostfixExpression` method of the `Notation` class.
     *
     * @throws InvalidNotationFormatException if an invalid notation format is encountered.
     */
    @Test
    public void testEvaluatePostfixExpression() throws InvalidNotationFormatException {
        // Test a simple postfix expression
        String postfixExpr1 = "3 4 +";
        double expectedResult1 = 7.0;
        double result1 = Notation.evaluatePostfixExpression(postfixExpr1);
        assertEquals(expectedResult1, result1, 0.001);

        // Test a postfix expression with operator precedence
        String postfixExpr2 = "3 4 2 * +";
        double expectedResult2 = 11.0;
        double result2 = Notation.evaluatePostfixExpression(postfixExpr2);
        assertEquals(expectedResult2, result2, 0.001);

        // Test a postfix expression with parentheses
        String postfixExpr3 = "3 4 + 2 *";
        double expectedResult3 = 14.0;
        double result3 = Notation.evaluatePostfixExpression(postfixExpr3);
        assertEquals(expectedResult3, result3, 0.001);
    }
}
