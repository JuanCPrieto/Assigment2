/**
 * The `QueueOverflowException` is a custom exception class that is used
 * to indicate errors related to attempting to enqueue an element into a full queue.
 */
public class QueueOverflowException extends Exception {
    /**
     * Constructor for `QueueOverflowException`.
     *
     * @param message A descriptive error message explaining the reason for the exception.
     */
    public QueueOverflowException(String message) {
        super(message);
    }
}

