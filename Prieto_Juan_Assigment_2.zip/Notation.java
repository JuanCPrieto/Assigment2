/**
 * The `Notation` class provides methods for converting and evaluating expressions
 * in infix and postfix notations.
 */
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Notation {
    /**
     * Converts an infix expression to a postfix expression.
     *
     * @param infixExpr The infix expression to be converted.
     * @return The equivalent postfix expression.
     * @throws InvalidNotationFormatException if the input expression is invalid.
     */
    public static String convertInfixToPostfix(String infixExpr) throws InvalidNotationFormatException {
        // Create a queue to hold the postfix expression and a stack for operators.
        Queue<String> postfixQueue = new LinkedList<>();
        Stack<Character> operatorStack = new Stack<>();

        for (char c : infixExpr.toCharArray()) {
            if (Character.isWhitespace(c)) {
                continue; // Skip whitespace
            } else if (Character.isDigit(c)) {
                // Append digits directly to the postfix expression queue
                StringBuilder operand = new StringBuilder();
                operand.append(c);

                while ((c = getNextChar(infixExpr)) != 0 && Character.isDigit(c)) {
                    operand.append(c);
                }

                postfixQueue.offer(operand.toString());
            } else if (isOperator(c)) {
                while (!operatorStack.isEmpty() && hasHigherPrecedence(c, operatorStack.peek())) {
                    postfixQueue.offer(operatorStack.pop().toString());
                }
                operatorStack.push(c);
            } else if (c == '(') {
                operatorStack.push(c);
            } else if (c == ')') {
                while (!operatorStack.isEmpty() && operatorStack.peek() != '(') {
                    postfixQueue.offer(operatorStack.pop().toString());
                }
                if (!operatorStack.isEmpty() && operatorStack.peek() == '(') {
                    operatorStack.pop();
                } else {
                    throw new InvalidNotationFormatException("Mismatched parentheses");
                }
            } else {
                throw new InvalidNotationFormatException("Invalid character: " + c);
            }
        }

        while (!operatorStack.isEmpty()) {
            if (operatorStack.peek() == '(') {
                throw new InvalidNotationFormatException("Mismatched parentheses");
            }
            postfixQueue.offer(operatorStack.pop().toString());
        }

        StringBuilder result = new StringBuilder();
        while (!postfixQueue.isEmpty()) {
            result.append(postfixQueue.poll()).append(" ");
        }

        return result.toString().trim();
    }

    /**
     * Converts a postfix expression to an infix expression.
     *
     * @param postfixExpr The postfix expression to be converted.
     * @return The equivalent infix expression.
     * @throws InvalidNotationFormatException if the input expression is invalid.
     */
    public static String convertPostfixToInfix(String postfixExpr) throws InvalidNotationFormatException {
        Stack<String> stack = new Stack<>();

        String[] tokens = postfixExpr.split("\\s+");
        for (String token : tokens) {
            if (isOperand(token)) {
                stack.push(token);
            } else if (isOperator(token)) {
                if (stack.size() < 2) {
                    throw new InvalidNotationFormatException("Invalid postfix expression");
                }
                String operand2 = stack.pop();
                String operand1 = stack.pop();
                String result = "(" + operand1 + " " + token + " " + operand2 + ")";
                stack.push(result);
            } else {
                throw new InvalidNotationFormatException("Invalid token in postfix expression: " + token);
            }
        }

        if (stack.size() != 1) {
            throw new InvalidNotationFormatException("Invalid postfix expression");
        }

        return stack.pop();
    }

    /**
     * Evaluates a postfix expression and returns the result.
     *
     * @param postfixExpr The postfix expression to be evaluated.
     * @return The result of the expression evaluation.
     * @throws InvalidNotationFormatException if the input expression is invalid.
     */
    public static double evaluatePostfixExpression(String postfixExpr) throws InvalidNotationFormatException {
        Stack<Double> stack = new Stack<>();
        String[] tokens = postfixExpr.split("\\s+");

        for (String token : tokens) {
            if (isOperand(token)) {
                stack.push(Double.parseDouble(token));
            } else if (isOperator(token)) {
                if (stack.size() < 2) {
                    throw new InvalidNotationFormatException("Invalid postfix expression");
                }
                double operand2 = stack.pop();
                double operand1 = stack.pop();
                double result = performOperation(operand1, operand2, token);
                stack.push(result);
            } else {
                throw new InvalidNotationFormatException("Invalid token in postfix expression: " + token);
            }
        }

        if (stack.size() != 1) {
            throw new InvalidNotationFormatException("Invalid postfix expression");
        }

        return stack.pop();
    }



    private static boolean isOperand(String token) {
        try {
            Double.parseDouble(token);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private static boolean isOperator(String token) {
        return token.matches("[+\\-*/]");
    }

    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }

    private static boolean hasHigherPrecedence(char op1, char op2) {
        return (op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-');
    }

    private static char getNextChar(String expr) {
        int index = expr.indexOf(expr);
        if (index < expr.length() - 1) {
            return expr.charAt(index + 1);
        }
        return 0;
    }

    private static double performOperation(double operand1, double operand2, String operator) throws InvalidNotationFormatException {
        switch (operator) {
            case "+":
                return operand1 + operand2;
            case "-":
                return operand1 - operand2;
            case "*":
                return operand1 * operand2;
            case "/":
                if (operand2 == 0) {
                    throw new InvalidNotationFormatException("Division by zero");
                }
                return operand1 / operand2;
            default:
                throw new InvalidNotationFormatException("Invalid operator: " + operator);
        }
    }
}

